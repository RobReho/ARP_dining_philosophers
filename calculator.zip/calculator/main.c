#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>

/* This function recognises the command got in stdin and forks the appropriate process that will
    execute the calculation.
    Input arguments:
        char op:    character received in stdin correspondig to the desired operation to perform;
        int a:      first number of the operation received in stdin;
        int b:      second number of the operation received in stdin;  */
int operation(char op, int a, int b);

/* This function gets the result computed by the child processes through a FIFO pipe.
    Input arguments:
        char oper:    character correspondig to the operation performed in the child process;  */
void result(char oper);

FILE *fp;
pid_t op_child;     //child process pid
int fdn, a, b;
char * myfifo = "/tmp/myfifo";  //named pipe

/* Log file */
void logprint(char msg[]){
    struct timeval current_time;
    gettimeofday(&current_time, NULL);
    fprintf(fp, "%li : %li :: main (%i): %s\n",current_time.tv_sec,current_time.tv_usec,getpid(),msg); 
    fflush(stdout);
}
    
int main(int argc, char *argv[]){
    
    //open log file
    fp  = fopen ("data.log", "a+");
    if (fp == NULL) perror("log file couldn't open\n");

    // Create named FIFO pipe
    mkfifo(myfifo, 0666);

    char oper;
    printf("insert commands in the form \nOp1 a b\nOp2 c\nOp3 d\n...\nwhere:\np = sum\nm = subtraction\nt = product\nd = division\ninser 'x' to close\n\n");
    fflush(stdout);

    //get first command from stdin
    scanf("%c %i %i", &oper, &a, &b);
    operation(oper,a,b);

    //get following commands from stdin
    while(1){
        
        scanf("%c", &oper);
        
        if(oper == 'x'){        //quit option
            logprint("closing\n___________________________________");
            printf("closing...\n"); fflush(stdout);
            close(fdn);     //close FIFO fd
            exit(0);
        }
        else{
            scanf("%i", &b);
            operation(oper,a,b);    //execute child process to compute the result and print on stdout
        }
    }

    return 0;
    
}

int operation(char op, int a, int b){

    char a_[16], b_[16], fd[16];
    sprintf(a_,"%d",a); 
    sprintf(b_,"%d",b); 
    sprintf(fd,"%d",fdn);

    char *argv_p[]={"./sum",a_,b_,fd,(char*)NULL};
    char *argv_m[]={"./sub",a_,b_,fd,(char*)NULL};
    char *argv_t[]={"./pro",a_,b_,fd,(char*)NULL};
    char *argv_d[]={"./div",a_,b_,fd,(char*)NULL};

    switch(op){
    case 'p':       //sum operation
        op_child = fork();

        if (op_child < 0){    //error on function fork
            perror("Fork");
            return -1;
        }

        if (op_child == 0){ //child process: execute sum
            if(execvp(argv_p[0], argv_p) == -1){
                perror("main - Exec_Error: exec sum");
                logprint("Exec_Error: exec sum");
                exit(-1);
            }
        }else{
            result('+');
        }
        break;

    case 'm':       //subtraction operation
         op_child = fork();
        if (op_child < 0){    //error on function fork
            perror("Fork");
            return -1;
        }

        if (op_child == 0){ //child process: execute subtraction
            if(execvp(argv_m[0], argv_d) == -1){
                perror("main - Exec_Error: exec sub");
                logprint("Exec_Error: exec sub");
                exit(-1);
            }
        }else
            result('-');
        break;

    case 't':       //product operation
        op_child = fork();
        if (op_child < 0){    //error on function fork
            perror("Fork");
            return -1;
        }

        if (op_child == 0){ //child process: execute product
            if(execvp(argv_t[0], argv_d) == -1){
                perror("main - Exec_Error: exec pro");
                logprint("Exec_Error: exec pro");
                exit(-1);
            }
        }else
            result('*');
        break;

    case 'd':       //division operation
        op_child = fork();
        if (op_child < 0){    //error on function fork
            perror("Fork");
            return -1;
        }

        if (op_child == 0){ //child process: execute division
            if(execvp(argv_d[0], argv_d) == -1){
                perror("main - Exec_Error: exec div");
                logprint("Exec_Error: exec div");
                exit(-1);
            }
        }else
            result('/');
        break;
    }
}


void result(char oper){
    struct timeval timestamp;     
    int stat;
    int ans;

    //open reading end of the named pipe
    fdn = open(myfifo,O_RDONLY);
    if(fdn == -1){
        perror("main - failed to open FIFO\n");
        logprint("failed to open FIFO");
    }

    usleep(100000);

    //signal child process 
    logprint("signaling child process");
    kill(op_child,SIGUSR1);

    if(read(fdn, &ans, 80)==-1){    //read answer from FIFO
        perror("main - Failed to read from FIFO");
        logprint("Failed to read from FIFO");
        close(fdn);
    }
    logprint("read from fifo");

    printf("%i %c %i = %i\n\n",a,oper,b,ans);   fflush(stdout);
    a = ans;
    close(fdn);

    waitpid(op_child, &stat, 0);  //waiting for child to return

    if (stat == -1){      //Verify if child process is terminated without error
        printf("\nThe child process terminated with an error!.\n"); 
        logprint("The child process terminated with an error!.");
    }
}