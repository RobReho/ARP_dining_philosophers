#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>

FILE *fp;
/* Log file */
void logprint(char msg[]){
    struct timeval current_time;
    gettimeofday(&current_time, NULL);
    fprintf(fp, "%li : %li :: sum (%i): %s\n",current_time.tv_sec,current_time.tv_usec,getpid(),msg); 
    fflush(stdout);
}
  
/* Signal handler:
    when the signal SIGUSR1 is received the process can continue and compute the operation.
    The endler only substitute the default behavior of the signal and print a message on the log file. */
void sig_handler(int signo)
{
	if(signo == SIGUSR1){
		logprint("signal received, computing...");
	}
}

int main(int argc, char *argv[]){
    signal(SIGUSR1, sig_handler);
    
    //open log file
    fp  = fopen ("data.log", "a+");
    if (fp == NULL) perror("log file couldn't open\n");
    logprint("invoked - sum child running");

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int fdn = atoi(argv[3]);
    int ans;
    char * myfifo = "/tmp/myfifo";

    //open writing end of the named pipe
    fdn = open(myfifo,O_WRONLY);
    if(fdn == -1){
        perror("sum - failed to open FIFO\n");
        logprint("failed to open FIFO");
        exit(-1);
    }

    logprint("waiting for signal");
    pause();    //wait for signal

    ans = a + b;
    
    logprint("writing back");
    //send the result of the calculation through the pipe
    if(write(fdn, &ans, sizeof(ans))==-1){
        perror("sum - failed to write on FIFO\n");
        logprint("failed to write to FIFO");
        exit(-1);
    }
    close(fdn);
    logprint("write end FIFO closed, child returning ");

return 0;
}
